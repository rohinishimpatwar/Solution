package com.zipcode;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Codes {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Codes cd = new Codes();
/* The data can be passed through command line arguments or file format.
 */
		System.out.println("If the data entered is through file enter f/F else enter A/a");
		Scanner sc = new Scanner(System.in);
		String entry = sc.next();
		if (entry.equals("F") || entry.equals("f")) {

			cd.getZipFileinput();
		} else {
			cd.getZipCodes();
		}

	}
/*The method takes the input from file and converts it into sorted TreeMap and passes it to the method for consolidated output */
	public void getZipFileinput() throws FileNotFoundException {
		
		Codes cd = new Codes();
		int count = 0;
		Scanner sc = null;
		try {

			sc = new Scanner(new File("./files/sample.txt"));
		} catch (FileNotFoundException fnf) {
			System.out.println("Please put file under location ...files/sample.txt");
		}

		try {
			while (sc.hasNextLine()) {
				String flag="Allowed";
				count++;
				String array = sc.nextLine();
				Map<Integer, Integer> mp = new TreeMap<Integer, Integer>();
				String[] line = array.split(" ");
				for (int i = 0; i < line.length; i++) {
					String[] arr = line[i].split(",");
                    String num1_str=arr[0].substring(1);
                    String num2_str=arr[1].substring(0,arr[1].length() - 1);
                   
					int num1 = Integer.parseInt(arr[0].substring(1));
                    
					int num2 = Integer.parseInt(arr[1].substring(0,arr[1].length() - 1));
					 if(num1_str.length()==5 && num2_str.length()==5 && num1<=num2){
	                	   mp.put(num1, num2);

	                   }
					 else{
                         flag="not allowed";
						 System.out.println();
						 System.out.println("The numbers for input "+count+" are either more or less than length 5 or the ranges are not in order [min,max]: the incorrect input ranges are ["+num1+","+num2+"]");
					     i=line.length;
					     
					      
					 }
                   
				}
				if(flag=="not allowed")	{
             	  System.out.println("Moving to next set of ranges if available ");
                }
				else{
				cd.sortzipcodes(mp, count);
				
				}
			}
		} catch (Exception nu) {
            System.out.println();
			System.out.println("The zipcodes entered for input line should be of 5 digits and in certain format eg: [12356,45677] [67877,89789] [98056,76589]");
		}

	}
/*
 * This method is used to get the zip codes through command line arguments and making it into Tree Map
 */
	public void getZipCodes() {
		// TODO Auto-generated method stub
		Codes cd = new Codes();
		int count = 0;
		System.out.println("Enter the data");
		Scanner sc = new Scanner(System.in);
		try {
			while (sc.hasNextLine()) {
				String flag="Allowed";
				String array = sc.nextLine();
				count++;
				Map<Integer, Integer> mp = new TreeMap<Integer, Integer>();

				String[] line = array.split(" ");

				for (int i = 0; i < line.length; i++) {

					String[] arr = line[i].split(",");
					 String num1_str=arr[0].substring(1);
	                    String num2_str=arr[1].substring(0,arr[1].length() - 1);
					int num1 = Integer.parseInt(arr[0].substring(1));

					int num2 = Integer.parseInt(arr[1].substring(0,arr[1].length() - 1));
					 if(num1_str.length()==5 && num2_str.length()==5 && num1<=num2){
	                	   mp.put(num1, num2);

	                   }
					 else{
                       flag="not allowed";
						 System.out.println();
						 System.out.println("The numbers for input "+count+" are either more or less than length 5 or the ranges are not in order [min,max]: the incorrect input ranges are ["+num1+","+num2+"]");
					     i=line.length;
					     
					      
					 }
                 
				}
				if(flag=="not allowed")	{
           	  System.out.println("Moving to next set of ranges if available ");
              }
				else{
				cd.sortzipcodes(mp, count);
				
				}
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("The zipcodes entered should be of 5 digits and in certain format eg: [12356,45677] [67877,89789] [98056,76589]");

		}

	}
/* 
	 This method is used to get the output from the Sorted Map
 */
	public void sortzipcodes(Map<Integer, Integer> mp, int count) {
		// TODO Auto-generated method stub
		System.out.println();
		System.out.println("The output for input " + count + " is :  ");

		Map<Integer, Integer> fmap = new TreeMap<Integer, Integer>();
		Set<Integer> set = mp.keySet();
		ArrayList<Integer> list = new ArrayList<Integer>(set);
		int len = 1;
		int min = list.get(0);
		int max = mp.get(list.get(0));

		while (len < list.size()) {

			if (max < list.get(len)) {

				fmap.put(min, max);
				min = list.get(len);
				max = mp.get(list.get(len));

				len++;
			} else if (min < mp.get(list.get(len - 1))
					&& max < mp.get(list.get(len))) {
				max = mp.get(list.get(len));
				len++;
			} else if (min < mp.get(list.get(len - 1))
					&& max > mp.get(list.get(len))) {

				len++;

			} else {

				fmap.put(list.get(len), mp.get(list.get(len)));
				len++;
			}
		}
		if (!fmap.containsKey(min)) {
			fmap.put(min, max);
		}
		// System.out.println("The consolidated ranges are " + fmap);

		Set<Integer> fset = fmap.keySet();

		for (int key : fset) {
			System.out.print("[" + key + "," + fmap.get(key) + "] ");
		}

	}
}